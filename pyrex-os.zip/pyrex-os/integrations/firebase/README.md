# integrations/firebase

Auto-generated module for PYREX OS.
