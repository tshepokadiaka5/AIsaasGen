# integrations/figma

Auto-generated module for PYREX OS.
