# docs/legal

Auto-generated module for PYREX OS.
